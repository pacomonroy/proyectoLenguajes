import java.util.Random;
import java.util.concurrent.atomic.*;

public class Guests extends Thread{

	//private String name;
	private Party party;
	//private AtomicInteger countDrinks;
	Random r = new Random();
	//private Visual v = new Visual(party.people,party)
	
	Guests (Party party){
		//this.name =name;
		//this.type =type;
		this.party =party;
		//this.countDrinks =new AtomicInteger(party.drinks);
		
	}
	
	
	
	
	public void run(){
    	int rt=r.nextInt(100)+1;
    	int rt2=r.nextInt(20)+10;
    	int rt3=r.nextInt(10)+5;
		int t=r.nextInt(2)+1;
    	int d=party.drinks;
    	int f=party.food;
    		
    	
    	switch(t) {
    	
    	case 1:
    		//guestName = "Marco";
    		//Drinker drinker = new Drinker();
        	//int cont2=party.countD;
    		
    		try {
    			if(rt2<=90) {
    				rt2=r.nextInt(8)+2;
    			}
    			party.addTime(rt2);
    			System.out.println("Drinker"+this.getName()+ "arrived to the party" +" at minute:" + party.time.get());
	    		while(party.countDrinks.get()>0) {

							//System.out.println("Drinker"+this.getName()+"consumed drink:"+party.countDrinks.get());
							party.restDrinks();
							System.out.println("Drink"+party.countDrinks.get() + "consumed by: "+this.getName());
							Thread.sleep(rt);
							
						}
	    					party.addTime(rt3);
							System.out.println("Drinker"+this.getName()+ "leaved the party"+" at minute:" + party.time.get());
							
				    		break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

						
					
					
	        		//cont2=drinker.consumeDrink(cont2);
	        		
				 

    		
    	case 2:
    		//guestName = "Paco";
    		//Eater eater = new Eater();
    		//int cont3=party.countF;
    		try {
    			if(rt2<=90) {
    				rt2=r.nextInt(8)+2;
    			}
    			party.addTime(rt2);
    			System.out.println("Eater"+this.getName()+ "arrived to the party" +"at minute:" + party.time.get());
	    		while(party.countDrinks.get()>0) {

							//System.out.println("Drinker"+this.getName()+"consumed drink:"+party.countDrinks.get());
							party.restFood();
							System.out.println("Food"+party.countFood.get() + "consumed by: "+this.getName());
							Thread.sleep(rt);
							
						}
	    					party.addTime(rt3);
	    					System.out.println("Eater"+this.getName()+ "leaved the party"+"at minute:" + party.time.get());
	    					
				    		
				    		break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		}

	
	
}}
