/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Random;

public class Party  {
	
	public String guestName;
	public int people,drinks,food,music;
	public int countD, countF;
	public AtomicInteger countDrinks,countFood;
	public AtomicInteger time = new AtomicInteger(0);
	public boolean drinkB,foodB;
	public Visual v;
	int rt;
	Random r = new Random();

	


	Party(int people, int drinks, int food , int music, Visual v){
		
	
		this.people = people;
		rt=r.nextInt(people)+2;
		this.drinks = drinks;
		this.countD = drinks;
		this.food = food;
		this.countF = food;
		this.music = music;
		this.drinkB=true;
		this.foodB=true;
		this.v= v;
		this.v.setDrink(drinks);
		this.v.setFood(food);
		this.v.setDrinksLeft(countD);
		this.v.setFoodLeft(countF);
		this.v.setPeopleI(people);
		this.v.setPeopleA(rt);
		this.v.setMinutes(0);
		this.v.setEntrance("");
		this.v.setActivity("");
		v.setVisible(false);
		v.setVisible(true);
		
		
	}
	
	public void setCounterDrinks(int drinks) {
		countDrinks = new AtomicInteger(drinks);
	}
	public void setCounterFood(int food) {
		countFood = new AtomicInteger(food);
	}
	
	public void addTime(int t) {
		time.getAndAdd(t);
		v.minutes= time.get();
		v.repaint();
	}
	public synchronized void restDrinks() {
		
		v.drinksLeft= countDrinks.get();
		v.repaint();
		//countDrinks.decrementAndGet();
		if(countDrinks.decrementAndGet()<1) {
			System.out.println("NO DRINKS");
			drinkB=false;
		
	}
		}
	public synchronized void restFood() {
		//countFood.decrementAndGet();
		v.foodLeft= countFood.get();
		v.repaint();
		if(countFood.decrementAndGet()<1){
			System.out.println("NO FOOD");;
			foodB=false;
		//countF -=f;
		}
		
		}
		/*
		 * 
		 * 	public synchronized void addDrinks(int d) {
		
		countD +=d;
		//count.addAndGet(d);
		
		
		
	}
	
	if(countD>=1) {
		countD -=d;
		}
		
	}
	public synchronized void addFood(int f) {
		countF +=f;
		
	}

*/
	
    /*public synchronized void run(){
    	int t=type;
    	int d=drinks;
    	int f=food;
    	switch(t) {
    	
    	case 1:
    		guestName = "Marco";
    		Drinker drinker = new Drinker();
        	int cont2=d;
        	while(cont2>0) {
        		System.out.println("Drinker arrived to the party");
        		//d--;
        		cont2=drinker.consumeDrink(cont2);
        		System.out.println("Drink"+cont2+ "consumed");
        	}
        	System.out.println("Drinker leaved the party");
    		
    		break;
    		
    	case 2:
    		guestName = "Paco";
    		Eater eater = new Eater();
    		int cont3=f;
    		while(cont3>0) {
    		System.out.println("Eater arrived to the party");
    		//d--;
    		cont3=eater.consumeFood(cont3);
    		System.out.println("Food"+cont3+ "consumed");
    	}
    	System.out.println("Eater leaved the party");
    	break;
    	}
    	*/
    	
    	//int cont=p;

        /*System.out.println("MyThread running");
        System.out.println(p);
        for(int i=0; i<p;i++) {
        	cont--;
        	System.out.println(cont);
        	
        }
        */
	
	/*public String getGuestName() {
	return guestName;
}


public void setGuestName(String guestName) {
	this.guestName = guestName;
}
*/

     } 
	


