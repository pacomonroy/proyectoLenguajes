/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/
import javax.swing.*;
import java.awt.*;
import java. awt. Graphics;
import java.awt.event.*;
import java.awt.Dimension;
import javax.swing.SwingUtilities;
public class Visual extends JFrame {
	//JButton b1;
	
    public int food,drink,foodLeft,drinksLeft, peopleI,peopleA, minutes;
    public String entrance, activity;
    
   

	   public int getFood() {
		return food;
	}


	public void setFood(int food) {
		this.food = food;
		
	}


	public int getDrink() {
		return drink;
	}


	public void setDrink(int drink) {
		this.drink = drink;
		
	}


	public int getFoodLeft() {
		return foodLeft;
	}


	public void setFoodLeft(int foodLeft) {
		this.foodLeft = foodLeft;
		foodLeft=foodLeft/15;
	}


	public int getDrinksLeft() {
		return drinksLeft;
	}


	public void setDrinksLeft(int drinksLeft) {
		this.drinksLeft = drinksLeft;
		drinksLeft=drinksLeft/35;
	}


	public int getPeopleI() {
		return peopleI;
	}


	public void setPeopleI(int peopleI) {
		this.peopleI = peopleI;
	}


	public int getPeopleA() {
		return peopleA;
	}


	public void setPeopleA(int peopleA) {
		this.peopleA = peopleA;
	}


	public int getMinutes() {
		return minutes;
	}


	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}


	public String getEntrance() {
		return entrance;
	}


	public void setEntrance(String entrance) {
		this.entrance = entrance;
	}


	public String getActivity() {
		return activity;
	}


	public void setActivity(String activity) {
		this.activity = activity;
	}


	public void paint(Graphics g) {
			
			//setSize(979,739);
			//setSize(980,750);
		   ImageIcon icon = new ImageIcon("img/house.png");
		   int x = 0;
		   int y = 100;
		   icon.paintIcon(this, g, x, y);
		   
		   g.drawString("Food investment: "+"$"+getFood(), 50, 50);
		   g.drawString("Drink investment: "+"$"+getDrink(), 50, 70);
		   g.drawString("People invited: "+getPeopleI(), 500, 50);
		   g.drawString("Total assistance: "+getPeopleA(), 800, 50);
		   g.drawString("Sodas Left: "+getDrinksLeft(), 450, 500);
		   g.drawString("Snacks Left: "+getFoodLeft(), 450, 550);
		   g.drawString("Activity: "+getActivity(), 500, 700);
		   g.drawString("Entrance: ", 50, 700);
		   g.drawString("                                            ", 50, 720);
		   g.drawString(getEntrance(), 50, 720);
		   g.drawString("                                            ", 800, 700);
		   g.drawString("Minutes passed:"+getMinutes(), 800, 700);
		   
		   
		
	   }


	public Visual() {
		//System.out.println("STRING"+s);
		//setPreferredSize(new Dimension(1280, 720));
        setLayout(new BorderLayout());
        setResizable(true);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new FlowLayout());
        //setContentPane(new JLabel(new ImageIcon("img/house.png")));
        
       // setPreferredSize(new Dimension(1280, 720));


        // Just for refresh :) Not optional!
        setSize(979,739);
        //refresh();
      setSize(980,750);
     // setVisible(true);
    }

}
