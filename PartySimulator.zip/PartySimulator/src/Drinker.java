import java.util.Random;
public class Drinker {
	
	public int consumeDrink(int drink) {
		int d;
		Random r = new Random();
		d= r.nextInt(5);
		//System.out.println("Drink:"+drink+"- d:"+d);
		drink= drink-d;
		//System.out.println(drink);
		return drink;
		
	}
	public int ConsumeFood(int food) {
		int f;
		Random r = new Random();
		f= r.nextInt(2);
		food=food-f;
		
		return food;
		
	}
}
