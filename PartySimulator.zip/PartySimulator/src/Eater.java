import java.util.Random;

public class Eater{
	
	public int consumeDrink(int drink) {
		int d;
		Random r = new Random();
		d= r.nextInt(2);
		//System.out.println("Drink:"+drink+"- d:"+d);
		drink= drink-d;
		//System.out.println(drink);
		return drink;
		
	}
	public int consumeFood(int food) {
		int f;
		Random r = new Random();
		f= r.nextInt(5);
		food=food-f;
		
		return food;
		
	}

}
