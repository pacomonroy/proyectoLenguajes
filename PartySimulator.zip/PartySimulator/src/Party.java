import java.util.concurrent.atomic.AtomicInteger;

public class Party  {
	
	public String guestName;
	public int people,drinks,food,music;
	public int countD, countF;
	public AtomicInteger countDrinks,countFood;
	public AtomicInteger time = new AtomicInteger(0);

	

	


	Party(int people, int drinks, int food , int music){
		this.people = people;
		this.drinks = drinks;
		this.countD = drinks;
		this.food = food;
		this.countF = food;
		this.music = music;
		
	}
	
	public void setCounterDrinks(int drinks) {
		countDrinks = new AtomicInteger(drinks);
	}
	public void setCounterFood(int food) {
		countFood = new AtomicInteger(food);
	}
	
	public void addTime(int t) {
		time.getAndAdd(t);
	}
	public synchronized void restDrinks() {
		if(countDrinks.get()>0) {
		countDrinks.getAndDecrement();
	}else {
		System.out.println("NO DRINKS");
	}
		}
	public synchronized void restFood() {
		countFood.getAndDecrement();
		//countF -=f;
		
	}
		/*
		 * 
		 * 	public synchronized void addDrinks(int d) {
		
		countD +=d;
		//count.addAndGet(d);
		
		
		
	}
	
	if(countD>=1) {
		countD -=d;
		}
		
	}
	public synchronized void addFood(int f) {
		countF +=f;
		
	}

*/
	
    /*public synchronized void run(){
    	int t=type;
    	int d=drinks;
    	int f=food;
    	switch(t) {
    	
    	case 1:
    		guestName = "Marco";
    		Drinker drinker = new Drinker();
        	int cont2=d;
        	while(cont2>0) {
        		System.out.println("Drinker arrived to the party");
        		//d--;
        		cont2=drinker.consumeDrink(cont2);
        		System.out.println("Drink"+cont2+ "consumed");
        	}
        	System.out.println("Drinker leaved the party");
    		
    		break;
    		
    	case 2:
    		guestName = "Paco";
    		Eater eater = new Eater();
    		int cont3=f;
    		while(cont3>0) {
    		System.out.println("Eater arrived to the party");
    		//d--;
    		cont3=eater.consumeFood(cont3);
    		System.out.println("Food"+cont3+ "consumed");
    	}
    	System.out.println("Eater leaved the party");
    	break;
    	}
    	*/
    	
    	//int cont=p;

        /*System.out.println("MyThread running");
        System.out.println(p);
        for(int i=0; i<p;i++) {
        	cont--;
        	System.out.println(cont);
        	
        }
        */
	
	/*public String getGuestName() {
	return guestName;
}


public void setGuestName(String guestName) {
	this.guestName = guestName;
}
*/

     } 
	


