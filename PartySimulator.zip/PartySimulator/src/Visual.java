import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Dimension;
import javax.swing.SwingUtilities;
public class Visual extends JFrame {
	//JButton b1;
    JLabel peopleVLable;
    JLabel drinksVLable;
    JLabel foodVLable;
    JLabel musicVLable;
    public String str;
    
    



	public void setStr(String str) {
		this.str = str;
	}
	
	public String getStr() {
		return str;
	}




	public void refresh(int people, int drinks, int food, int music) {
        peopleVLable=new JLabel("|| NUMBER OF PEOPLE: "+people);
        drinksVLable=new JLabel("|| DRINKS BUDGET: "+drinks);
        foodVLable=new JLabel("|| FOOD BUDGET: "+food);
        musicVLable=new JLabel("|| MUSIC: "+music+" ||");
        peopleVLable.setSize(200, 200);
     
       // add(peopleVLable);
      //  add(drinksVLable);
        //add(foodVLable);
        //add(musicVLable);
		setSize(979,739);
	    setSize(980,750);
		
	}

	public Visual() {
		//System.out.println("STRING"+s);
		//setPreferredSize(new Dimension(1280, 720));
        setLayout(new BorderLayout());
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new JLabel(new ImageIcon("img/house.png")));
        setLayout(new FlowLayout());
        setPreferredSize(new Dimension(1280, 720));


        // Just for refresh :) Not optional!
      //setSize(617,347);
        //refresh();
      //setSize(618,448);
    }

}
