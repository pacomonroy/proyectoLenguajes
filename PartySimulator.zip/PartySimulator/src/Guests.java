/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/
import java.util.Random;
import java.util.concurrent.atomic.*;

public class Guests extends Thread{

	//private String name;
	private Party party;
	
	//private AtomicInteger countDrinks;
	Random r = new Random();
	

	

       //v.refresh(people,party.countDrinks.get(),party.countFood.get(),music);
		//v.repaint();
	
	
	//private Visual v = new Visual(party.people,party)
	
	Guests (Party party){
		//this.name =name;
		//this.type =type;
		this.party =party;
		//this.countDrinks =new AtomicInteger(party.drinks);

		
		
    	

		
		
	}
	
	
	
	
	public void run(){
		
		
    	int rt=r.nextInt(100)+1;
    	int rt2=r.nextInt(20)+10;
    	int rt3=r.nextInt(10)+5;
		int t=r.nextInt(2)+1;
    	int d=party.drinks;
    	int f=party.food;
    	
    	
    		
    	
    	switch(t) {
    	
    	case 1:
    		//guestName = "Marco";
    		//Drinker drinker = new Drinker();
        	//int cont2=party.countD;
    		
    		try {
    			if(rt2<=90) {
    				rt2=r.nextInt(8)+2;
    			}
    			party.addTime(rt2);
    			party.v.setEntrance(this.getName()+ "arrived to the party");
    			party.v.repaint();
    			System.out.println(this.getName()+ "arrived to the party" +" at minute:" + party.time.get());
    			//System.out.println("Drinker"+this.getName()+ "arrived to the party" +" at minute:" + party.time.get());
	    		while(party.drinkB) {

							//System.out.println("Drinker"+this.getName()+"consumed drink:"+party.countDrinks.get());
							party.restDrinks();
							System.out.println("Drink"+party.countDrinks.get() + "consumed by: "+this.getName());
							party.v.setActivity("Drink"+party.countDrinks.get() + "consumed by: "+this.getName());
							party.v.repaint();
							Thread.sleep(rt);
							
							
						}
	    					party.addTime(rt3);
							System.out.println("Drinker"+this.getName()+ "leaved the party"+" at minute:" + party.time.get());
							party.v.setEntrance(this.getName()+ "leaved the party");
							party.v.repaint();
				    		break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

						
					
					
	        		//cont2=drinker.consumeDrink(cont2);
	        		
				 

    		
    	case 2:
    		//guestName = "Paco";
    		//Eater eater = new Eater();
    		//int cont3=party.countF;
    		try {
    			if(rt2<=90) {
    				rt2=r.nextInt(8)+2;
    			}
    			party.addTime(rt2);
    			party.v.setEntrance(this.getName()+ "arrived to the party");
    			party.v.repaint();
    			System.out.println(this.getName()+ "arrived to the party" +"at minute:" + party.time.get());
    			//System.out.println("Eater"+this.getName()+ "arrived to the party" +"at minute:" + party.time.get());
	    		while(party.foodB) {

							//System.out.println("Drinker"+this.getName()+"consumed drink:"+party.countDrinks.get());
							party.restFood();
							System.out.println("Food"+party.countFood.get() + "consumed by: "+this.getName());
							party.v.setActivity("Drink"+party.countDrinks.get() + "consumed by: "+this.getName());
							party.v.repaint();
							Thread.sleep(rt);
							
						}
	    					party.addTime(rt3);
	    					System.out.println("Eater"+this.getName()+ "leaved the party"+"at minute:" + party.time.get());
	    					party.v.setEntrance(this.getName()+ "leaved the party");
	    					party.v.repaint();
				    		
				    		break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		}

	
	
}}
