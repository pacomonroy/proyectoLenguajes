import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Dimension;
import javax.swing.SwingUtilities;
public class View extends JFrame {
	
	int x = 0;
	int y = 0;
	
	public void changeDim() {
		x=x+1;
		y=y+1;
	}
	
    public void paint(Graphics g) {
    	super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.fillOval(x, y, 30, 30);
     }
    public View() {
    	
    	

    }
}
