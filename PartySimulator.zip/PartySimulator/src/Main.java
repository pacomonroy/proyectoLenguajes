import java.util.Scanner;
import java.util.Random;
import java.awt.event.*; 
import javax.swing.*; 
import java.awt.Color;
import java.util.concurrent.atomic.AtomicInteger;
public class Main extends JFrame implements ActionListener{
	public static Thread guest;
	
    // JTextField 
    static JTextField peopleField,drinksField,foodField; 
    
  
    // JFrame 
    static JFrame f; 
  
    // JButton 
    static JButton b; 
  
    // label to diaplay text 
    static JLabel l,peopleLabel,drinksLabel,foodLabel; 


  
    // default constructor 
    Main() 
    { 
    } 

	public static void main(String[] args) {
		

		f = new JFrame("PARTY SIMULATOR"); 
		//f.getContentPane().setBackground(new Color(255,0,0));
		
		// create a new frame to stor text field and button 
  
        // create a label to display text 
        l = new JLabel("nothing entered"); 
        
        peopleLabel = new JLabel("Number of people :");
    	peopleLabel.setBounds(10, 10, 100, 100);
        drinksLabel = new JLabel("Drinks budget :");
    	drinksLabel.setBounds(10, 10, 100, 100);
        foodLabel = new JLabel("Food budget :");
    	foodLabel.setBounds(10, 10, 100, 100);
  
        // create a new button 
        b = new JButton("SIMULATE"); 
  
        // create a object of the text class 
        Main te = new Main(); 
  
        // addActionListener to button 
        b.addActionListener(te); 
  
        // create a object of JTextField with 16 columns 
        peopleField = new JTextField(16); 
        drinksField = new JTextField(16); 
        foodField = new JTextField(16); 
 
  
        // create a panel to add buttons and textfield 
        JPanel p = new JPanel(); 
  
        // add buttons and textfield to panel 
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        p.add(peopleLabel);
        p.add(peopleField); 
        p.add(drinksLabel);
        p.add(drinksField);
        p.add(foodLabel);
        p.add(foodField); 
        p.add(b); 
        p.add(l); 
  
        // add panel to frame 
        f.add(p); 
  
        // set the size of frame 
        f.setSize(300, 300); 
  
        f.show(); 
    

        AtomicInteger count;
        boolean b = true;
		int rt,people,food,drinks,music;
		
		Random r = new Random();
		Main m = new Main();
		Scanner sc = new Scanner(System.in);
		//Party[] guests = new Party[100];
		
		
		
		
		System.out.println("---------------------------------");
		System.out.println("Welcome to Party simulator");
		System.out.println("---------------------------------");
		System.out.println("");
		System.out.println("Number of people:");
		people=sc.nextInt();
		//Guests g[] = new Guests[people];
		
		System.out.println(people);
		System.out.println("Food budget:");
		food=sc.nextInt();
		System.out.println("Drinks budget:");
		drinks=sc.nextInt();
		//count =new AtomicInteger(drinks);
		System.out.println("");
		System.out.println("---------------------------------");
		System.out.println("");
		System.out.println("Select the type of music you will play:");
		System.out.println("");
		System.out.println("1. Rock | 2. Electronic | 3. Reggaeton | 4. Banda");
		
		music=sc.nextInt();
		Party party = new Party(people,drinks,food,music);
		party.setCounterDrinks(drinks);
		party.setCounterFood(food);
		
		for(int i=0;i<people;i++) {
			rt=r.nextInt(10)+1;
			guest = new Guests(party);
			try {
				Thread.sleep(10);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			guest.start();
			

			//System.out.println(guest.getName());
		}
		
		//myThread.start();
		
		
		
	}

	//pubic synchrionized void lessDrinks(int n)
	//
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String s = e.getActionCommand(); 
		String peopleS,drinksS,foodS;
		int type,people,drinks,food,music;
		boolean bo = true;
		Random r = new Random();
		
        if (s.equals("SIMULATE")) { 
        	
        	//String sp = "HOLI BOLI";
    		//
    		//v.setStr("Holi");
    		//System.out.println(v.getStr());
    		//v.setVisible(true);
        	
        	
        	
            // set the text of the label to the text of the field 
            //l.setText(peopleField.getText()); 
            peopleS = peopleField.getText();
            people = Integer.parseInt(peopleS);	
            //Party guests[] = new Party[people];

            
            drinksS = drinksField.getText();
            drinks = Integer.parseInt(drinksS);	
            
            foodS= foodField.getText();
            food = Integer.parseInt(foodS);
            music = 1;
            //Visual v = new Visual(people,drinks,food,music);
           // v.setVisible(true);
            
    		Party party = new Party(people,drinks,food,music);
    		party.setCounterDrinks(drinks);
    		party.setCounterFood(food);
    		
    		/*View vi = new View();
    			vi.setSize(500, 500);
    			vi.setVisible(true);
    				vi.changeDim();
        			vi.repaint();
    		*/	
    			
    			

    		
    	Visual v = new Visual();
           v.refresh(people,party.countDrinks.get(),party.countFood.get(),music);
           v.setVisible(true);
    		for(int i=0;i<people;i++) {

    			int rt=r.nextInt(10)+1;
    			guest = new Guests(party);
    			try {
    				Thread.sleep(10);
    				
    				
    			} catch (InterruptedException ex) {
    				// TODO Auto-generated catch block
    				ex.printStackTrace();
    			}
    			
    			guest.start();
    			if(!(guest.isAlive())) {
    				System.out.println("PARTY ENDED");
    			}
    			
    			

    			//System.out.println(guest.getName());
    		}
    		
            
            
    		/*for(int i=0;i<people;i++) {
    			type=r.nextInt(2)+1;
    			// guests[i] = new PeopleThread(this)
    			guests[i] = new Party(type,people,drinks,food,music);
    			guests[i].setName("Pepe");
    			guests[i].start();
    			
    			l.setText(guests[i].getName());
    		}
    		*/
            // set the text of field to blank 
            //peopleField.setText(peopleS);
            
        } 
		// TODO Auto-generated method stub
		
	}
	
	
	


	//ThreadPeople
	
	//if(drinker)
	// this.lessDrinks(n);
		

}
